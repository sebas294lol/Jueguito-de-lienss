package com.example.trayectoria;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    ShotField field;
    SeekBar curve, power;
    TextView curveV, powerV, status, score, shots;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14,14,14,14);
        root.setBackgroundColor(Color.rgb(16,20,24));

        TextView title = text("⚽ Trayectoria de Tiros 2.0", 21, Color.WHITE);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView help = text("Toca o arrastra en la portería para apuntar. El portero intenta detener el tiro.", 12, Color.LTGRAY);
        help.setPadding(0,3,0,8); root.addView(help);

        field = new ShotField(this);
        root.addView(field, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(10,8,10,8);
        panel.setBackgroundColor(Color.rgb(25,31,37));

        curve = bar(-30,30,0); curveV = text("0",13,Color.LTGRAY);
        power = bar(1,10,6); powerV = text("6",13,Color.LTGRAY);
        addRow(panel,"Curva",curve,curveV); addRow(panel,"Potencia",power,powerV);

        LinearLayout stats = new LinearLayout(this);
        score = text("Goles: 0",13,Color.WHITE); shots = text("  Tiros: 0/5",13,Color.WHITE);
        stats.addView(score); stats.addView(shots); panel.addView(stats);

        LinearLayout buttons = new LinearLayout(this);
        Button shoot = new Button(this); shoot.setText("⚽ Disparar");
        Button reset = new Button(this); reset.setText("↻ Nuevo desafío");
        buttons.addView(shoot,new LinearLayout.LayoutParams(0,58,1));
        buttons.addView(reset,new LinearLayout.LayoutParams(0,58,1));
        panel.addView(buttons);

        status = text("Apunta y pulsa Disparar.",13,Color.LTGRAY); panel.addView(status);
        root.addView(panel,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);

        curve.setOnSeekBarChangeListener(listener());
        power.setOnSeekBarChangeListener(listener());
        shoot.setOnClickListener(v -> {
            if(field.anim) return;
            field.shoot(power.getProgress());
            status.setText("Tiro en curso…");
        });
        reset.setOnClickListener(v -> field.newChallenge());
    }

    TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    SeekBar bar(int min,int max,int value){SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(value-min);s.setTag(min);return s;}
    void addRow(LinearLayout p,String name,SeekBar s,TextView v){LinearLayout r=new LinearLayout(this);TextView l=text(name,13,Color.LTGRAY);l.setMinWidth(65);r.addView(l);r.addView(s,new LinearLayout.LayoutParams(0,48,1));r.addView(v);p.addView(r);}
    SeekBar.OnSeekBarChangeListener listener(){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){int min=(int)s.getTag();int val=p+min;if(s==curve){curveV.setText(""+val);field.curve=val;}else{powerV.setText(""+val);}field.invalidate();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};}

    class ShotField extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Path path=new Path();
        float targetX=142,targetY=45,curve=0,bx=18,by=45,keeperX=135;
        long start; int duration=800; boolean anim=false; int goals=0, total=0; boolean resultShown=false;
        RectF goal=new RectF();
        ShotField(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        float sx(){return getWidth()*.11f;} float gx(){return getWidth()*.91f;}
        float sy(){return by/90f*getHeight();}
        float ty(){return targetY/90f*getHeight();}
        float tx(){return targetX/160f*getWidth();}
        float keeperPx(){return keeperX/160f*getWidth();}
        @Override protected void onDraw(Canvas c){
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(62,125,66)); c.drawRoundRect(0,0,getWidth(),getHeight(),22,22,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.argb(190,255,255,255));
            RectF r=new RectF(getWidth()*.07f,getHeight()*.07f,getWidth()*.93f,getHeight()*.93f);c.drawRect(r,p);
            c.drawLine(getWidth()/2,getHeight()*.07f,getWidth()/2,getHeight()*.93f,p);
            goal.set(getWidth()*.86f,getHeight()*.30f,getWidth()*.96f,getHeight()*.70f);p.setStrokeWidth(6);c.drawRect(goal,p);
            p.setStrokeWidth(1);p.setColor(Color.argb(70,255,255,255));
            for(int i=1;i<6;i++){float yy=goal.top+(goal.height()*i/6f);c.drawLine(goal.left,yy,goal.right,yy,p);}
            float cy=Math.max(8,Math.min(82,45-curve*.72f));
            path.reset();path.moveTo(sx(),45/90f*getHeight());path.quadTo(getWidth()*.50f,cy/90f*getHeight(),tx(),ty());
            p.setStrokeWidth(5);p.setColor(Color.WHITE);p.setPathEffect(new DashPathEffect(new float[]{10,8},0));c.drawPath(path,p);p.setPathEffect(null);
            // target marker
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.YELLOW);c.drawCircle(tx(),ty(),10,p);
            // goalkeeper
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(40,70,180));c.drawRoundRect(keeperPx()-18,getHeight()*.45f,keeperPx()+18,getHeight()*.60f,8,8,p);
            p.setColor(Color.rgb(240,210,170));c.drawCircle(keeperPx(),getHeight()*.41f,10,p);
            // ball
            p.setColor(Color.WHITE);c.drawCircle(bx/160f*getWidth(),by/90f*getHeight(),9,p);
            if(anim){
                float q=Math.min(1,(System.currentTimeMillis()-start)/(float)duration);
                float cx=Math.max(8,Math.min(82,45-curve*.72f));
                float x=18+(targetX-18)*q;
                float yy=(1-q)*(1-q)*45+2*(1-q)*q*cx+q*q*targetY;
                bx=x;by=yy;
                keeperX=120+18*(float)Math.sin((System.currentTimeMillis()-start)/220.0);
                if(q<1){postInvalidateDelayed(16);}else{anim=false;finishShot();}
            }
        }
        void shoot(int pow){duration=1450-pow*85;start=System.currentTimeMillis();anim=true;invalidate();}
        void finishShot(){
            total++;
            float dist=Math.abs(targetX-keeperX)+Math.abs(targetY-53)*0.7f;
            boolean blocked=dist<23;
            boolean inGoal=targetX>=138 && targetY>=27 && targetY<=63;
            if(inGoal && !blocked){goals++;status.setText("¡GOOOL! 🎯");}else if(blocked){status.setText("¡El portero la atajó! 🧤");}else{status.setText("Fuera de la portería. Prueba otro punto.");}
            score.setText("Goles: "+goals);shots.setText(String.format(Locale.US,"  Tiros: %d/5",total));
            if(total>=5){status.setText("Desafío terminado: "+goals+"/5 goles. Pulsa Nuevo desafío.");}
            bx=18;by=45;invalidate();
        }
        void newChallenge(){goals=0;total=0;targetX=142;targetY=45;curve=0;bx=18;by=45;keeperX=135;anim=false;curve.setProgress(30);power.setProgress(5);score.setText("Goles: 0");shots.setText("  Tiros: 0/5");status.setText("Nuevo desafío. Apunta y dispara.");invalidate();}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(anim)return true;
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                float nx=e.getX()/getWidth()*160f, ny=e.getY()/getHeight()*90f;
                if(nx>=125 && ny>=18 && ny<=72){targetX=Math.max(132,Math.min(150,nx));targetY=Math.max(22,Math.min(68,ny));invalidate();}
                return true;
            }
            return true;
        }
    }
}
