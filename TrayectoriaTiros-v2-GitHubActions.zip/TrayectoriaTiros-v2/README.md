# Trayectoria de Tiros 2.0

Versión independiente de práctica de tiros. Incluye apuntado táctil, curva, potencia, portero, zonas de portería, marcador y desafío de 5 tiros.

## Compilación con GitHub Actions
Sube el contenido del proyecto al repositorio y ejecuta `Actions > Build APK v2 > Run workflow`.

Nota: esta versión usa el mismo `applicationId` pero incrementa `versionCode` a 2. Si el APK anterior fue generado con otra clave de firma, Android puede pedir desinstalar la v1 antes de instalar la v2.
