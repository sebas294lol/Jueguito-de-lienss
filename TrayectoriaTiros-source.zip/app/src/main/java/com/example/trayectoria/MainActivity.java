package com.example.trayectoria;

import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import android.content.*;import java.util.*;

public class MainActivity extends Activity {
  Field field; SeekBar curve,height,power; TextView cv,hv,pv,status;
  @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,18); root.setBackgroundColor(Color.rgb(16,20,24));
    TextView title=new TextView(this); title.setText("⚽ Trayectoria de Tiros"); title.setTextColor(Color.WHITE); title.setTextSize(21); title.setPadding(0,0,0,12); root.addView(title);
    field=new Field(this); root.addView(field,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(10,10,10,10); panel.setBackgroundColor(Color.rgb(25,31,37));
    curve=bar(); height=bar(); power=bar();
    cv=val();hv=val();pv=val(); addRow(panel,"Curva",curve,cv);addRow(panel,"Altura",height,hv);addRow(panel,"Potencia",power,pv);
    LinearLayout buttons=new LinearLayout(this); Button shoot=new Button(this);shoot.setText("⚽ Disparar");Button reset=new Button(this);reset.setText("↻ Reiniciar");buttons.addView(shoot,new LinearLayout.LayoutParams(0,55,1));buttons.addView(reset,new LinearLayout.LayoutParams(0,55,1));panel.addView(buttons);
    status=val();status.setText("Ajusta los controles y pulsa Disparar.");panel.addView(status);root.addView(panel,new LinearLayout.LayoutParams(-1,-2)); setContentView(root);
    curve.setMax(60);curve.setProgress(30);height.setMax(60);height.setProgress(30);power.setMax(9);power.setProgress(5); sync();
    View.OnClickListener l=v->{field.shoot(power.getProgress()+1);status.setText("Tiro en curso…");};shoot.setOnClickListener(l);reset.setOnClickListener(v->{curve.setProgress(30);height.setProgress(30);power.setProgress(5);field.reset();sync();status.setText("Listo.");});
    SeekBar.OnSeekBarChangeListener sl=new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){sync();field.invalidate();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};curve.setOnSeekBarChangeListener(sl);height.setOnSeekBarChangeListener(sl);power.setOnSeekBarChangeListener(sl);
  }
  SeekBar bar(){SeekBar s=new SeekBar(this);s.setLayoutParams(new LinearLayout.LayoutParams(0,48,1));return s;} TextView val(){TextView t=new TextView(this);t.setTextColor(Color.LTGRAY);t.setTextSize(13);return t;} void addRow(LinearLayout p,String n,SeekBar s,TextView v){LinearLayout r=new LinearLayout(this);TextView l=val();l.setText(n);l.setMinWidth(65);r.addView(l);r.addView(s);r.addView(v);p.addView(r);} void sync(){cv.setText(""+(curve.getProgress()-30));hv.setText(""+(height.getProgress()+20));pv.setText(""+(power.getProgress()+1));field.curve=curve.getProgress()-30;field.y=height.getProgress()+20;field.invalidate();}

  class Field extends View { Paint p=new Paint(1); float curve=0,y=50,bx=18,by=50; long start=0;int duration=700;boolean anim=false; RectF r=new RectF(); Field(Context c){super(c);p.setStrokeWidth(5);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    protected void onDraw(Canvas c){super.onDraw(c);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(62,125,66));c.drawRoundRect(0,0,getWidth(),getHeight(),22,22,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.argb(180,255,255,255));r.set(getWidth()*.07f,getHeight()*.07f,getWidth()*.93f,getHeight()*.93f);c.drawRect(r,p);c.drawLine(getWidth()/2,getHeight()*.07f,getWidth()/2,getHeight()*.93f,p);p.setStrokeWidth(6);r.set(getWidth()*.86f,getHeight()*.33f,getWidth()*.95f,getHeight()*.67f);c.drawRect(r,p);
      float sy=y/90f*getHeight(), ey=sy, cy=Math.max(7,Math.min(83,45-curve*.75f));Path path=new Path();path.moveTo(getWidth()*.11f,sy);path.quadTo(getWidth()*.47f,cy/90f*getHeight(),getWidth()*.91f,ey);p.setStrokeWidth(5);p.setPathEffect(new android.graphics.DashPathEffect(new float[]{10,8},0));c.drawPath(path,p);p.setPathEffect(null);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(bx/160f*getWidth(),by/90f*getHeight(),9,p);
      if(anim){float q=Math.min(1,(System.currentTimeMillis()-start)/(float)duration);float x=18+127*q;float yy=(1-q)*(1-q)*y+2*(1-q)*q*cy+q*q*y;bx=x;by=yy;if(q<1){postInvalidateDelayed(16);}else{anim=false;post(()->status.setText("¡Tiro completado!"));}} }
    void shoot(int pow){duration=1300-pow*80;start=System.currentTimeMillis();anim=true;invalidate();}void reset(){anim=false;bx=18;by=y;invalidate();}
  }
}
